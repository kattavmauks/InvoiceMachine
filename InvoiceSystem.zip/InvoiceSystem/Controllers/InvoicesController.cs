using Microsoft.AspNetCore.Mvc;


[ApiController]
[Route("[controller]")]
public class InvoicesController : ControllerBase
{
    private readonly InvoiceService _invoiceService;

    public InvoicesController(InvoiceService invoiceService)
    {
        _invoiceService = invoiceService;
    }

    [HttpPost]
    public IActionResult CreateInvoice([FromBody] Invoice invoice)
    {
        invoice.Id = Guid.NewGuid().ToString();
        invoice.Status = "pending";
        _invoiceService.AddInvoice(invoice);
        return CreatedAtAction(nameof(GetInvoiceById), new { id = invoice.Id }, new { id = invoice.Id });
    }

    [HttpGet]
    public IActionResult GetInvoices()
    {
        var invoices = _invoiceService.GetAllInvoices();
        return Ok(invoices);
    }

    [HttpGet("{id}")]
    public IActionResult GetInvoiceById(string id)
    {
        var invoice = _invoiceService.GetInvoiceById(id);
        if (invoice == null) return NotFound();
        return Ok(invoice);
    }

    [HttpPost("{id}/payments")]
    public IActionResult PayInvoice(string id, [FromBody] Payment payment)
    {
        var invoice = _invoiceService.GetInvoiceById(id);
        if (invoice == null) return NotFound();

        invoice.PaidAmount += payment.Amount;
        if (invoice.PaidAmount >= invoice.Amount) invoice.Status = "paid";

        _invoiceService.UpdateInvoice(invoice);
        return Ok();
    }

    [HttpPost("process-overdue")]
    public IActionResult ProcessOverdue([FromBody] OverdueProcessRequest request)
    {
        var overdueInvoices = _invoiceService.GetAllInvoices()
            .Where(i => i.Status == "pending" && i.DueDate < DateTime.Now)
            .ToList();

        foreach (var invoice in overdueInvoices)
        {
            if (invoice.PaidAmount > 0)
            {
                invoice.Status = "paid";
                var newInvoice = new Invoice
                {
                    Id = Guid.NewGuid().ToString(),
                    Amount = (invoice.Amount - invoice.PaidAmount) + request.LateFee,
                    DueDate = DateTime.Now.AddDays(request.OverdueDays),
                    Status = "pending"
                };
                _invoiceService.AddInvoice(newInvoice);
            }
            else
            {
                invoice.Status = "void";
                var newInvoice = new Invoice
                {
                    Id = Guid.NewGuid().ToString(),
                    Amount = invoice.Amount + request.LateFee,
                    DueDate = DateTime.Now.AddDays(request.OverdueDays),
                    Status = "pending"
                };
                _invoiceService.AddInvoice(newInvoice);
            }

            _invoiceService.UpdateInvoice(invoice);
        }

        return Ok();
    }
}
