public class OverdueProcessRequest
{
    public decimal LateFee { get; set; }
    public int OverdueDays { get; set; }
}
