public class InvoiceService
{
    private readonly List<Invoice> _invoices = new List<Invoice>();

    public IEnumerable<Invoice> GetAllInvoices() => _invoices;

    public Invoice GetInvoiceById(string id)
    {
        return _invoices.FirstOrDefault(i => i.Id == id);
    }

    public void AddInvoice(Invoice invoice) => _invoices.Add(invoice);

    public void UpdateInvoice(Invoice invoice)
    {
        var index = _invoices.FindIndex(i => i.Id == invoice.Id);
        if (index != -1) _invoices[index] = invoice;
    }
}
